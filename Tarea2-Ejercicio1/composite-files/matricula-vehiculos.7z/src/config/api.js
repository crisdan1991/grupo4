const BASE_TRX_WEB_API = import.meta.env.VITE_BASE_TRX_WEB_API;

export {BASE_TRX_WEB_API };